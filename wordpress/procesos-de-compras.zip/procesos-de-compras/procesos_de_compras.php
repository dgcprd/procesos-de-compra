<?php

/*
Plugin Name: Procesos de Compras
Plugin URI: https://www.edwardceballos.com
Description: Muestra los detalles de los procesos de compra gestionados a través del Sistema Electrónico de Contrataciones Públicas (SECP) - Portal Transaccional.
Version: 0.1
Author: Dirección General de Contrataciones Públicas por Edward Ceballos Camacho
Author URI: https://www.edwardceballos.com
*/

define('PROCESS_DIR', plugin_dir_path(__FILE__));

require_once( PROCESS_DIR . 'processes_class.php' );

function processes_settings_init() {
	register_setting( 'processes', 'processes_options' );

	add_settings_section(
		'processes_section',
		__( 'Configuración para mostrar detalles de los Procesos de Compra', 'processes' ), 'processes_section_callback',
		'processes'
	);

	add_settings_field(
		'codigo_uc',
		__( 'Código de Unidad de Compras (UC)', 'processes' ),
		'add_processes_setings_text',
		'processes',
		'processes_section',
		array(
			'label_for'         => 'codigo_uc',
			'class'             => 'processes_row',
			'processes_custom_data' => '000007',
			'type' => 'text',
			'description' => 'Si no sabe cual es su código de unidad de compra o puede consultarlo en el enlace <a href="https://www.dgcp.gob.do/instituciones-implementadas/" target="_blank">https://www.dgcp.gob.do/instituciones-implementadas/</a>.',
		)
	);

	add_settings_field(
		'color_text',
		__( 'Color para títulos', 'processes' ),
		'add_processes_setings_text',
		'processes',
		'processes_section',
		array(
			'label_for'         => 'color_text',
			'class'             => 'processes_row',
			'processes_custom_data' => '#1761c3',
			'type' => 'color',
			'description' => '',
		)
	);

	add_settings_field(
		'color_text2',
		__( 'Color para títulos (Franja blanca)', 'processes' ),
		'add_processes_setings_text',
		'processes',
		'processes_section',
		array(
			'label_for'         => 'color_text2',
			'class'             => 'processes_row',
			'processes_custom_data' => '#1761c3',
			'type' => 'color',
			'description' => '',
		)
	);

	add_settings_field(
		'color_bg',
		__( 'Color para fondo de los títulos', 'processes' ),
		'add_processes_setings_text',
		'processes',
		'processes_section',
		array(
			'label_for'         => 'color_bg',
			'class'             => 'processes_row',
			'processes_custom_data' => '#e1f1ff',
			'type' => 'color',
			'description' => '',
		)
	);

	add_settings_field(
		'color_buttom',
		__( 'Color para el botón', 'processes' ),
		'add_processes_setings_text',
		'processes',
		'processes_section',
		array(
			'label_for'         => 'color_buttom',
			'class'             => 'processes_row',
			'processes_custom_data' => '#1761c4',
			'type' => 'color',
			'description' => '',
		)
	);

	add_settings_field(
		'font',
			__( 'Incluir FontAwesome', 'processes' ),
		'add_processes_setings',
		'processes',
		'processes_section',
		array(
			'label_for'         => 'font',
			'class'             => 'processes_row',
			'processes_custom_data' => '1',
			'description' => '',
		)
	);

	add_settings_field(
		'css',
			__( 'Incluir modulo de Bootstrap 4', 'processes' ),
		'add_processes_setings',
		'processes',
		'processes_section',
		array(
			'label_for'         => 'css',
			'class'             => 'processes_row',
			'processes_custom_data' => '1',
			'description' => '',
		)
	);
}

add_action( 'admin_init', 'processes_settings_init' );

function processes_section_callback( $args ) {
	?>
	<div  id="<?php echo esc_attr( $args['id'] ); ?>">
		<p>Para incluir los detalles de sus procesos de compra copie y pegue el siguiente fragmento de código en la página deseada:</p>
		<textarea style="background:#fff; border:none; resize:none;" onfocus="this.select();" readonly rows="1">[list_processes]</textarea>
	</div>
	<?php
}


function add_processes_setings_text( $args ) {
	$options = get_option( 'processes_options' );
	?>

	<input
		id="<?php echo esc_attr( $args['label_for'] ); ?>"
		data-custom="<?php echo esc_attr( $args['processes_custom_data'] ); ?>"
		name="processes_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
		type="<?php echo esc_attr( $args['type'] ); ?>"
		value="<?php echo isset( $options[ $args['label_for'] ] ) ? ( $options[ $args['label_for'] ] ) : ( $args['processes_custom_data'] ); ?>"
		style="min-width: 200px; max-width: 100%;" />

	<p class="description"><?php echo ( $args['description'] ); ?></p>
	<?php
}


function add_processes_setings( $args ) {
	$options = get_option( 'processes_options' );
	?>
	<select
			style="min-width: 200px; max-width: 100%;"
			id="<?php echo esc_attr( $args['label_for'] ); ?>"
			data-custom="<?php echo esc_attr( $args['processes_custom_data'] ); ?>"
			name="processes_options[<?php echo esc_attr( $args['label_for'] ); ?>]">

		<option value="1" <?php echo isset( $options[ $args['label_for'] ] ) ? ( selected( $options[ $args['label_for'] ], '1', false ) ) : ( '' ); ?>>
			<?php esc_html_e( 'Sí', 'processes' ); ?>
		</option>

 		<option value="0" <?php echo isset( $options[ $args['label_for'] ] ) ? ( selected( $options[ $args['label_for'] ], '0', false ) ) : ( '' ); ?>>
			<?php esc_html_e( 'No', 'processes' ); ?>
		</option>

	</select>

	<p class="description"><?php echo ( $args['description'] ); ?></p>
	<?php
}

function processes_options_page() {
	add_menu_page(
		'Configuración Procesos de Compra',
		'Configuración Procesos de Compra',
		'manage_options',
		'processes',
		'processes_options_page_html',
		'dashicons-index-card'
	);
}

add_action( 'admin_menu', 'processes_options_page' );

function processes_options_page_html() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	if ( isset( $_GET['settings-updated'] ) ) {
		add_settings_error( 'processes_messages', 'processes_message', __( 'Configuración Guardada', 'processes' ), 'updated' );
	}

	settings_errors( 'processes_messages' );
	?>
	<div class="wrap">
		<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
		<form action="options.php" method="post">
			<?php
			settings_fields( 'processes' );
			do_settings_sections( 'processes' );
			submit_button( 'Guardar Configuración' );
			?>
		</form>
	</div>
	<?php
}


add_shortcode( 'list_processes', 'getProcessesData');